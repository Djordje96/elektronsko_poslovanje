<?php

//1. Ucitavanje css i js fajlova u nasu wordpress stranicu
function add_mef_scripts()
{
    /*
    za dodavanje css fajlova
        prvi argument je imenovanje fajlova (deskriptivnog karaktera)
        drugi je kombinacija wordpress metode da  se dobije parcijalna lokacija naseg template-a
    */
    wp_enqueue_style('css', get_stylesheet_uri());
    wp_enqueue_style('main-css', get_template_directory_uri() . '/assets/css/main.css');
    wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/css/fontawesome-all.min.css');
    wp_enqueue_style('noscript', get_template_directory_uri().'/assets/css/noscript.css');

    /* 
    za dodavanje js fajlova
        prvi argument je imenovanje fajlova (deskriptivnog karaktera)
        drugi argument kombinacije wordpress metode da se dobije parcijalna lokacija naseg template-a i lokacije fajla kojeg zelimo da ucitamo
        trecu argument je da li taj fajl koji ucitavamo, zavisi od nekog drugog fajla
        cetvrti argument je verzija skripte ili fajla koji ucitavamo (proizvoljne prirode)
        peti argument (true ili false), je da li zelimo da se skripta ucita u footeru ili headeru naseg fajla
    */
    wp_enqueue_script( 'breakpoints', get_template_directory_uri() . '/assets/js/breakpoints.min.js', NULL, 1.0, true);
    wp_enqueue_script( 'browser', get_template_directory_uri() . '/assets/js/browser.min.js', NULL, 1.0, true);
    wp_enqueue_script( 'jquery', get_template_directory_uri() . '/assets/js/jquery.min.js', NULL, 1.0, true);
    wp_enqueue_script( 'jquery-scrollex', get_template_directory_uri() . '/assets/js/jquery.scrollex.min.js', NULL, 1.0, true);
    wp_enqueue_script( 'main', get_template_directory_uri() . '/assets/js/main.js', NULL, 1.0, true);
    wp_enqueue_script( 'util', get_template_directory_uri() . '/assets/js/util.js', NULL, 1.0, true);
}
// akcija koja pokrece funkciju koja ucitava sve nase resurse u wordpress 
add_action('wp_enqueue_scripts', 'add_mef_scripts');

//2. Registrovanje navigacije kako bi WordPress prepoznao da nas sajt ima navigaciju
function register_mef_navigation()
{
    register_nav_menu('header-menu', __('Glavni meni'));
}
add_action('init', 'register_mef_navigation');


function mef_woocommerce_support()
{
    add_theme_support( 'woocommerce', array(
        'thumbnail_image_width' => 150,
        'single_image_width'    => 300,

        'product_grid'          => array(
            'default_rows'    => 3,
            'min_rows'        => 2,
            'max_rows'        => 8,
            'default_columns' => 3,
            'min_columns'     => 2,
            'max_columns'     => 5,
        ),
    ) );


}
add_action( 'after_setup_theme', 'mef_woocommerce_support' );

add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
function loop_columns() {
    return 3; // 3 products per row
}
}
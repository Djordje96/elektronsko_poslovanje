<?php 
    get_header();
?>
<style>
img {
    max-width: 100%;
    height: auto;
    display:block;
}</style>


<section id="wrapper">
	<header>
		<div class="inner">
			<h2><?php the_title()?></h2>
            <a href="<?=site_url('blog')?>">Ostali blogovi</a>
			<p>Napisao/la: <?= get_the_author()?></p>
		</div>
	</header>

	<!-- Content -->
		<div class="wrapper">
			<div class="inner">
                <?= the_content()?>
			</div>
            <div class="navigation">
            <span>
            <?php previous_post_link(); ?>
            </span>
           
            <span style="float:right;"> 
                <?php next_post_link(); ?>
            </span>
           
            </div>
		</div>
        
</section>

<?php 

    get_footer();
?>
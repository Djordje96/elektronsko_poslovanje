<?php 
	get_header();

	$args = array(
		'post_type' => 'banner',
		'posts_per_page' => 1,
		'order' => 'ASC',
	);
	$banner = new WP_Query( $args );

	// The Loop
	if ( $banner->have_posts() ) {
		while ( $banner->have_posts() ) {
			$banner->the_post();
			?>
	<!-- Banner -->
	<section id="banner">
		<div class="inner">
			<div class="logo"><span class="icon fa-gem"></span></div>
			<h2><?= the_title()?></h2>
			<p><?= the_content()?></p>
		</div>
	</section>

			<?php
		}
	} else {
		// no posts found
}
/* Resetuje wordpressovu The Loop nazad u normalni tok */
	wp_reset_postdata();
?>

<!-- Wrapper -->
<section id="wrapper">

	<!-- One -->
		<section id="one" class="wrapper spotlight style1">
			<div class="inner">
				<a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a>
				<div class="content">
					<h2 class="major"><?= the_field('first_heading_advert')?></h2>
					<p><?=the_field('first_content_box')?></p>
				</div>
			</div>
		</section>

	<!-- Two -->
		<section id="two" class="wrapper alt spotlight style2">
			<div class="inner">
				<a href="#" class="image"><img src="images/pic02.jpg" alt="" /></a>
				<div class="content">
					<h2 class="major"><?= the_field('second_heading_advert');?></h2>
					<p><?= the_field('second_content_box')?></p>
				</div>
			</div>
		</section>

	<!-- Three -->
		<section id="three" class="wrapper spotlight style3">
			<div class="inner">
				<a href="#" class="image"><img src="images/pic03.jpg" alt="" /></a>
				<div class="content">
					<h2 class="major"><?= the_field('third_heading_advert');?></h2>
					<p><?= the_field('third_content_box')?></p>
				</div>
			</div>
		</section>
	<!-- Four -->
		<section id="four" class="wrapper alt style1">
			<div class="inner">
				<h2 class="major">Blog:</h2>
				<p>Izdvajamo najpopularnije delove iz naseg bloga !</p>
				<section class="features">
<?php 

$args = array(
	'post_type' => 'post',
	'posts_per_page' => 4,
);
$posts = new WP_Query( $args );

if ( $posts->have_posts() ) {
	while ( $posts->have_posts() ) {
		$posts->the_post(); 
		?>
			<article>
				<a href="#" class="image"><img src="images/pic04.jpg" alt="" /></a>
				<h3 class="major"><?=the_title()?></h3>
				<p><?= wp_trim_words(get_the_content(),18)?></p>
				<a href="<?=get_the_permalink()?>" class="special">Saznajte vise !</a>
			</article>
		<?php
	} 
} 
wp_reset_postdata(); // reset WP_Query loop
?>
				</section>
				<ul class="actions">
					<li><a href="<?= site_url('blog')?>" class="button">Pogledajte sve !</a></li>
				</ul>
			</div>
		</section>

</section>

<!-- Footer -->
<section id="footer">
	<div class="inner">
		<h2 class="major">Javite nam se !</h2>
		<p>Obecavamo da necemo koristiti Vas email u svrhe newsletter-a ili reklama ;)</p>
		<form method="post" action="#">
			<?= do_shortcode('[wpforms id="109"]')?>
		</form>
		<ul class="contact">
			
		</ul>
		<ul class="copyright">
			<li>&copy; Mef Inc. All rights reserved.</li><li>Design: <a href="#">djole</a></li>
		</ul>
	</div>
</section>

<?php 
    get_footer();
?>
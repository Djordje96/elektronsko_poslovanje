</div> <!-- Kraj za wrapping div -->
</body>
<?php wp_footer();?>
</html>
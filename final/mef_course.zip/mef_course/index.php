<?php 
    get_header();
?>
<?php 
    if(is_page('cart') || is_cart()) {
    	echo ('<section id="wrapper"> <div class="inner">');
        echo do_shortcode('[woocommerce_cart]');
        echo ('</div></section>');
    }else{

?>
<section id="wrapper">
	<header>
		<div class="inner">
			<h2>Svi Blogovi !</h2>
		</div>
	</header>

	<!-- Content -->
		<div class="wrapper">
			<div class="inner">
				<section class="features">
				<?php 
if ( have_posts() ) {
	while ( have_posts() ) {
		the_post(); ?>
			<article>
				<a href="#" class="image"><img src="<?= has_post_thumbnail() ? the_post_thumbnail_url(): 'https://via.placeholder.com/420x230'?>" alt="" /></a>
				<h3 class="major"><?=the_title()?></h3>
				<p><?= wp_trim_words(get_the_content(),18)?></p>
				<a href="<?=get_the_permalink()?>" class="special">Saznajte vise !</a>
			</article>
		<?php
	} // end while
} // end if

?>
				</section><hr>
<h4>Paginacija: </h4>
<?php the_posts_pagination()?>
			</div>
		</div>

</section>

<?php }
    get_footer();
?>